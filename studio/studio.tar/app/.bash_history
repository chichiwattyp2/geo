wget https://cdn.glitch.com/95e6aa22-9326-46d1-9f72-577534eb0acd%2Fdownload%20(1).png?v=1591260014262
wget https://cdn.glitch.com/95e6aa22-9326-46d1-9f72-577534eb0acd%2Fdownload%20(1).png
wget https://cdn.glitch.com/95e6aa22-9326-46d1-9f72-577534eb0acd%2Fstudio.png?v=1591260358529
